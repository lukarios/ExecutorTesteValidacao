
package executortestevalidacao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

class Persistence {
   static private EntityManagerFactory emf = null;
   static private EntityManager em = null;

   static EntityManager getPersistenceManager() throws Exception {
       if (em == null) {
           emf = javax.persistence.Persistence.createEntityManagerFactory("TestToolPU");
           em = emf.createEntityManager();
       }
       return em;
   }
} // Persistence
