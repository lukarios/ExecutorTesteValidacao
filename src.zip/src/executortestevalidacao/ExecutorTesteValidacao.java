
package executortestevalidacao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.PersistenceException;

import java.util.Collection;
import java.util.ArrayList;
import java.util.Date;

import br.org.fdte.persistence.*;

import java.io.OutputStream;

import executortestevalidacao.ExecutionCallback.ExecutionEvent;
import executortestevalidacao.AtributesAndValues.Atribute;
import executortestevalidacao.AtributesAndValues.Value;
import executortestevalidacao.AtributesAndValues.AtributeIterator;



public class ExecutorTesteValidacao {


   public enum ExecutionMode { GOLDEN_FILE, SYSTEM_TEST, SYSTEM_EXERCIZE };
   public enum ExecutionResult { SUCCESS, FAILURE, TIMEOUT };

   protected ExecutionCallback executionCallback;
   protected ExecucaoTesteValidacao currentExecution;

   protected String suite;
   protected ExecutionMode mode;
   protected int numOfThreads;
   protected OutputStream logStream;
   protected boolean abort;
   protected boolean abortNow = false;

   private NegativeTestExecution negativeTestExecution = null;
   private PositiveTestExecution positiveTestExecution = null;
   private TestModeExecution testModeExecution = null ;
   
   private RetrievalResult retrieve (CaracterizacaoTesteValidacao teste) {
       RetrievalResult res = new RetrievalResult();
       res.result = ExecutionResult.SUCCESS;
       res.document = new AtributesAndValues();
       Atribute a = res.document.newAtribute();
       a.name = "atr1";
       res.document.set(a, "valor1");
       return res;
   } // retrieve
   
   private ExecutionResult submit (CaracterizacaoTesteValidacao teste,
                                   AtributesAndValues doc) {
       ExecutionResult res = ExecutionResult.SUCCESS;
       return res;       
   } // submit

   protected RetrievalResult executeActivation (CaracterizacaoTesteValidacao teste,
                                                AtributesAndValues inputDoc,
                                                long activationId ) {
       fireEvent(ExecutionCallback.ExecutionEventType.ATIVATION_STARTED, "Activation", activationId, "");
       ExecutionResult res = ExecutionResult.SUCCESS;
       inputDoc.dump("Id" + activationId);
       res = submit(teste, inputDoc);
       RetrievalResult retRes = retrieve(teste);
       res = retRes.result;
       ExecutionCallback.ExecutionEventType etv = ExecutionCallback.ExecutionEventType.ATIVATION_ENDED_SUCCESS;
       if (res.equals(ExecutionResult.FAILURE))
           etv = ExecutionCallback.ExecutionEventType.ATIVATION_ENDED_FAIL;
       if (res.equals(ExecutionResult.TIMEOUT))
           etv = ExecutionCallback.ExecutionEventType.ATIVATION_ENDED_TIMEOUT;
       fireEvent(etv, "Activation", activationId, "");
       return retRes;
   }


   protected void persistActivation(CaracterizacaoTesteValidacao teste,
                                    AtributesAndValues validDoc,
                                    AtributesAndValues retDoc,
                                    long activationId,
                                    boolean positiveTeste,
                                    ExecutionResult executionResult,
                                    long activationStarted) throws Exception {

       if ((mode.equals(ExecutionMode.GOLDEN_FILE)) || (mode.equals(ExecutionMode.SYSTEM_TEST))) {
           Persistence.getPersistenceManager().getTransaction().begin();
           AtivacaoTesteValidacao atv = new AtivacaoTesteValidacao();
           atv.setDocumentoEntrada(validDoc.getBytes());
           atv.setDocumentoSaida(retDoc.getBytes());
           atv.setIdExecucaoTesteValidacao(currentExecution);
           atv.setSequencial((int) activationId);
           atv.setTipo(positiveToString(positiveTeste));
           atv.setResultado(resultToString(executionResult));
           atv.setInicio(new Date(activationStarted));
           atv.setTermino(new Date(System.currentTimeMillis()));
           Persistence.getPersistenceManager().persist(atv);
           Persistence.getPersistenceManager().getTransaction().commit();
       }
   } // persistActivation

   private TestResults executeNegativeTests(CaracterizacaoTesteValidacao t,
                                            Collection<Especificos> especificos) throws Exception {
       negativeTestExecution = new NegativeTestExecution(suite,
                                                         mode,
                                                         numOfThreads,
                                                         logStream,
                                                         abort,
                                                         currentExecution,
                                                         0);
       negativeTestExecution.setExecutionCallback(executionCallback);
       TestResults res = negativeTestExecution.executeNegativeTests(t, especificos);
       return res;
   } // executeNegativeTests

   private TestResults executePositiveTests(CaracterizacaoTesteValidacao t,
                                            Collection<Especificos> especificos
                                            ) throws Exception {
       long initialId = negativeTestExecution.getLastActivationId();
       positiveTestExecution = new PositiveTestExecution(suite,
                                                         mode,
                                                         numOfThreads,
                                                         logStream,
                                                         abort,
                                                         currentExecution,
                                                         initialId);
       positiveTestExecution.setExecutionCallback(executionCallback);
       TestResults res = positiveTestExecution.executePositiveTests(t, especificos);
       return res;
   } // executeNegativaTests

   private TestResults executeInTestMode(CaracterizacaoTesteValidacao t) throws Exception {

       int initialId = 0;
       testModeExecution = new TestModeExecution(suite,
                                                         mode,
                                                         numOfThreads,
                                                         logStream,
                                                         abort,
                                                         currentExecution,
                                                         initialId);
       testModeExecution.setExecutionCallback(executionCallback);
       TestResults res = testModeExecution.executeTests(t);
       return res;
   } // executeNegativaTests

   private ExecutionResult executeValidationTest (SuiteTesteValidacao suite,
                                          CaracterizacaoTesteValidacao t) throws Exception {
       fireEvent(ExecutionCallback.ExecutionEventType.TEST_STARTED, "Test", t.getId(), t.getNome());
       ExecutionResult res = ExecutionResult.SUCCESS;

       if ( (mode.equals(ExecutionMode.GOLDEN_FILE)) || (mode.equals(ExecutionMode.SYSTEM_TEST))) {
          persistTestExecution(t, suite);
       }

       TestResults finalResults = new TestResults();
       TestResults results = null;

       if ( (mode == ExecutionMode.GOLDEN_FILE) || (mode == ExecutionMode.SYSTEM_EXERCIZE)) {
           Collection<Especificos> especificos = t.getEspecificosCollection();
           results = executeNegativeTests(t, especificos);
           finalResults.accumulate(results);
           results = executePositiveTests(t, especificos);
           finalResults.accumulate(results);
       } else if (mode == ExecutionMode.SYSTEM_TEST) {
           finalResults = executeInTestMode(t);
       }
       if ( (mode.equals(ExecutionMode.GOLDEN_FILE)) || (mode.equals(ExecutionMode.SYSTEM_TEST))) {
           persistTestExecutionResults(finalResults);
       }
       fireEvent(ExecutionCallback.ExecutionEventType.TEST_ENDED, "Test", t.getId(), t.getNome());
       return res;
   } // executeValidationTest

   public ExecutionResult executeValidationSuite(String suite,
                                      ExecutionMode mode,
                                      int numOfThreads,
                                      OutputStream logStream,
                                      boolean abort) throws ExecuteValidationTestException {
       this.suite = suite;
       this.mode = mode;
       this.numOfThreads = numOfThreads;
       this.logStream = logStream;
       this.abort = abort;

       try {
           EntityManager em = Persistence.getPersistenceManager();
           Query q = em.createNamedQuery("SuiteTesteValidacao.findByNome");
           q.setParameter("nome", suite);
           SuiteTesteValidacao stv = (SuiteTesteValidacao)q.getSingleResult();
           if (stv == null) {
               throw new ExecuteValidationTestException (ExecuteValidationTestException.ExceptionType.SUITE_NOT_FOUND, "Nome da suite: " + suite);
           }
           fireEvent(ExecutionCallback.ExecutionEventType.SUITE_STARTED, "Suite", stv.getId(), "Suite " + suite + "Mode " + mode + " Abort " + abort + " Threads " + numOfThreads);
           Collection<CaracterizacaoTesteValidacao> tests = stv.getCaracterizacaoTesteValidacaoCollection();
           if ( mode.equals(ExecutionMode.GOLDEN_FILE)) {
               removePrevious(tests);
           }
           ExecutionResult res = ExecutionResult.SUCCESS;
           for ( CaracterizacaoTesteValidacao t : tests) {
               res = executeValidationTest(stv, t);
               if ( needAbort(res) ) {
                   fireEvent(ExecutionCallback.ExecutionEventType.SUITE_ABORTED, "Suite", stv.getId(), "Suite " + suite);
                   break;
               }
           } // for each test within suite
           em.close();
           fireEvent(ExecutionCallback.ExecutionEventType.SUITE_ENDED, "Suite", stv.getId(), "Suite " + suite);
           return res;
       } catch(PersistenceException pe) {
           pe.printStackTrace();
           throw new ExecuteValidationTestException(ExecuteValidationTestException.ExceptionType.DATABASE_ACCESS_ERROR,
                                                     pe.toString());
       } catch(Exception e) {
           e.printStackTrace();
           throw new ExecuteValidationTestException(ExecuteValidationTestException.ExceptionType.GENERIC_EXCEPTION,
                                                     e.toString());

       } // end catch
   } // executeValidationTest

   private void persistTestExecutionResults(TestResults results) throws Exception {
        Persistence.getPersistenceManager().getTransaction().begin();
        currentExecution.setTermino(new Date());
        currentExecution.setCasosFalha(results.negative_negative + results.positive_negative);
        currentExecution.setCasosSucesso(results.positive_positive + results.negative_positive);
        currentExecution.setCasosTimeout(results.timeout);
        Persistence.getPersistenceManager().persist(currentExecution);
        Persistence.getPersistenceManager().getTransaction().commit();
   } //persistTestExecutionResults

   private void persistTestExecution(CaracterizacaoTesteValidacao t, SuiteTesteValidacao suite) throws Exception {
        Persistence.getPersistenceManager().getTransaction().begin();
        ExecucaoTesteValidacao etv = currentExecution = new ExecucaoTesteValidacao();
        etv.setIdCaracterizacaoTesteValidacao(t);
        etv.setIdSuite(suite);
        etv.setInicio(new Date());
        etv.setModoAtivacao(modeToString(mode));
        etv.setRelatorio("".getBytes()); // workaround : field must not be null
        Persistence.getPersistenceManager().persist(etv);
        Persistence.getPersistenceManager().getTransaction().commit();
    } // persistTestExecution

   protected void fireEvent(ExecutionCallback.ExecutionEventType type, String objectType, long id, String msg) {
       if (executionCallback != null) {
           ExecutionEvent evt = new ExecutionEvent();
           evt.eventType = type;
           evt.objectType = objectType;
           evt.objectId = id;
           evt.message = msg;
           evt.timestamp = System.currentTimeMillis();
           executionCallback.executionEventHandler(evt);
       }
   } // fireEvent

   public void setExecutionCallback(ExecutionCallback executionCallback) {
       this.executionCallback = executionCallback;
   } // setExecutionCallback

   protected boolean needAbort(ExecutionResult res) {
      if (abortNow)
          return true;
      if (abort && ( (res == ExecutionResult.FAILURE) || ( res == ExecutionResult.TIMEOUT))) {
          return true;
      }
      return false;
   } // needAbort


   protected static String positiveToString(boolean positive) {
       if (positive)
           return "P";
       return "N";
   } // positiveToString
   
   protected static String modeToString(ExecutionMode mode) {
       if ( mode.equals(ExecutionMode.GOLDEN_FILE))
           return "G";
       if (mode.equals(ExecutionMode.SYSTEM_TEST))
           return "T";
       if (mode.equals(ExecutionMode.SYSTEM_EXERCIZE))
           return "E";
       return null;
   } // modeToString

   static private String resultToString(ExecutionResult res) {
     if ( res.equals(ExecutionResult.SUCCESS))
         return "S";
     if (res.equals(ExecutionResult.FAILURE))
         return "F";
     if (res.equals(ExecutionResult.TIMEOUT))
         return "T";
     return null;
   } // resultToString

   protected class RetrievalResult {
       ExecutionResult result;
       AtributesAndValues document;
   } // RetrievalResult

   protected void removePrevious(Collection<CaracterizacaoTesteValidacao> tests) throws Exception {
       Collection<String> testsToRemove = new ArrayList<String>();
       for (CaracterizacaoTesteValidacao c : tests) {
           testsToRemove.add(c.getNome());
       }
       removePreviousExecution(testsToRemove);
   } //removePrevious

   public void removePreviousExecution(Collection<String> validationTestNames) throws Exception{
       try {
           EntityManager em = Persistence.getPersistenceManager();
           em.getTransaction().begin();
           for ( String nome : validationTestNames) {
               Query q1 = em.createNamedQuery("CaracterizacaoTesteValidacao.findByNome");
               q1.setParameter("nome", nome);
               CaracterizacaoTesteValidacao t = (CaracterizacaoTesteValidacao)q1.getSingleResult();
               Query q2 = em.createNamedQuery("ExecucaoTesteValidacao.findAllExecutions");
               q2.setParameter("idCaracTstValid", t);
               Collection<ExecucaoTesteValidacao> execs = q2.getResultList();
               if ( execs != null) {
                   for ( ExecucaoTesteValidacao ex : execs) {                       
                       Query q3 = em.createNamedQuery("AtivacaoTesteValidacao.deleteByExecution");
                       q3.setParameter("execution", ex);
                       q3.executeUpdate();
                       em.remove(ex);
                   }
              }
           }
           em.getTransaction().commit();
       } catch(PersistenceException pe) {
           pe.printStackTrace();
           throw new ExecuteValidationTestException(ExecuteValidationTestException.ExceptionType.DATABASE_ACCESS_ERROR,
                                                     pe.toString());
       } catch(Exception e) {
           e.printStackTrace();
           throw new ExecuteValidationTestException(ExecuteValidationTestException.ExceptionType.GENERIC_EXCEPTION,
                                                     e.toString());
       } // end catch
   } // removePreviousExecution

   public Collection<String> checkForExistingGoldenfile(String suite)
                                         throws ExecuteValidationTestException {
       try {
           Collection<String> retval = new ArrayList<String>();
           EntityManager em = Persistence.getPersistenceManager();
           Query q = em.createNamedQuery("SuiteTesteValidacao.findByNome");
           q.setParameter("nome", suite);
           SuiteTesteValidacao stv = (SuiteTesteValidacao)q.getSingleResult();
           if (stv == null) {
               return null;
           }
           Collection<CaracterizacaoTesteValidacao> tests = stv.getCaracterizacaoTesteValidacaoCollection();
           for ( CaracterizacaoTesteValidacao t : tests) {
               q = em.createNamedQuery("ExecucaoTesteValidacao.findGoldenExecution");
               q.setParameter("modoAtivacao", "G");
               q.setParameter("idCaractTstValidacao", t);
               Collection<ExecucaoTesteValidacao> execs = q.getResultList();
               if ( execs != null) {
                   retval.add(t.getNome());
               }
           } // for each test within suite
           return retval;
       } catch(PersistenceException pe) {
           pe.printStackTrace();
           throw new ExecuteValidationTestException(ExecuteValidationTestException.ExceptionType.DATABASE_ACCESS_ERROR,
                                                     pe.toString());
       } catch(Exception e) {
           e.printStackTrace();
           throw new ExecuteValidationTestException(ExecuteValidationTestException.ExceptionType.GENERIC_EXCEPTION,
                                                     e.toString());
       } // end catch
   } // executeValidationTest

   public void abortExecution() {
     abortNow = true;
     if ( negativeTestExecution != null) {
        negativeTestExecution.abortNow = true;
     }
     if ( positiveTestExecution != null) {
        positiveTestExecution.abortNow = true;
     }
   } // abortExecution

   public class TestResults {
       int positive_positive = 0;
       int positive_negative = 0;
       int negative_positive = 0;
       int negative_negative = 0;
       int timeout = 0;

       void accumulate(TestResults t) {
           positive_positive += t.positive_positive;
           positive_negative += t.positive_negative;
           negative_positive += t.negative_positive;
           negative_negative += t.negative_negative;
           timeout += t.timeout;
       } // accumulate
   } // TestResults
} // ExecutorTesteValidacao
